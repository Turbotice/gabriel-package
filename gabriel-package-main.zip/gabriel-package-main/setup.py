#%%
from setuptools import setup, find_packages

setup(
    name = 'fcd_codes', 
    version = '0.1',
    description = 'FCD codes (Antonin Eddi, Stephane Perrard, Mina Jafari, Baptiste Auvity, Gabriel Le Doudic)',
    url = 'needs a URL',
    author = 'Gabriel Le Doudic',
    author_email = 'gabriel.le-doudic@outlook.fr',
    license = 'PMMH',
    packages = find_packages(),
    zip_safe = False, 
)